# termite > 2024-09-07 9:17am
https://universe.roboflow.com/test-hhymk/termite-rtlzw-p0tbl

Provided by a Roboflow user
License: CC BY 4.0

